框架说明
==========

依赖
-------------

- Maven
- SpringCloudAlibaba 2.2.3
- dubbo 2.7.8
- Nacos 1.3.0
- Seata 1.2.0
- Mybatis Tk
- Mysql 5.7.30 (创建数据库脚本: test.sql，仅仅作为示例)
- Redis
- Mongodb
- Druid
- Swagger2
- Lombok
- HuTool

工程介绍
---------------------

- hunting-app			APP接口（供APP调用）
- hunting-admin		管理后台(前端服务，示例页面采用thymeleaf)
- hunting-openapi		开放平台SDK接口（供客户自有系统调用）
- hunting-portal-core	服务消费者公共组件（供前端服务调用）
- hunting-api			服务调用
- hunting-common		公共类
- hunting-svc-core	服务提供者公共组件（供后台服务调用）
- hunting-svc-admin	角色权限后台管理等服务（后台服务）
- hunting-svc-device	设备服务（后台服务）
- hunting-svc-user	用户服务（后台服务）

注：以上项目都能编译通过

开发环境构建操作指导
----------------

### zookeeper

#### （1）下载：

https://www.apache.org/dyn/closer.lua/zookeeper/zookeeper-3.6.2/apache-zookeeper-3.6.2-bin.tar.gz

#### （2）解压：

到D:\apache-zookeeper-3.6.2-bin

#### （3）环境变量：

ZOOKEEPER_HOME=D:\apache-zookeeper-3.6.2-bin
PATH增加%ZOOKEEPER_HOME%\bin

#### （4）配置：

将conf目录下的zoo_sample.cfg文件，复制一份，重命名为zoo.cfg
把dataDir=/tmp/zookeeper 改为：
       
```
dataDir=D:\apache-zookeeper-3.6.2-bin\data
dataLogDir=D:\apache-zookeeper-3.6.2-bin\log`
```   
增加一行：admin.serverPort=8092

#### （5）运行

zkServer.cmd


#### 问题1：

2021-01-07 16:52:18,594 [myid:] - WARN  [NIOWorkerThread-1:NIOServerCnxn@373] - Close of session 0x0
java.io.IOException: Len error 1195725856

解决：客户端升级到3.4.7以上

#### 问题2：

java.lang.NoSuchMethodError: org.springframework.boot.builder.SpringApplicationBuilder.<init>([Ljava/lang/Object;)V

解决：
spring-cloud-zookeeper-dependencies和Spring cloud版本不一致，换成一样的就行了

#### 问题3：

2021-01-07 17:42:19.148 INFO  [hunting-svc-user] org.apache.zookeeper.ClientCnxn:1029 - Opening socket connection to server localhost/0:0:0:0:0:0:0:1:2181. Will not attempt to authenticate using SASL (unknown error)
2021-01-07 17:42:20.148 INFO  [hunting-svc-user] org.apache.zookeeper.ClientCnxn:1166 - Socket error occurred: localhost/0:0:0:0:0:0:0:1:2181: Connection refused: no further information

解决：


### 2、dubbo

#### （1）dubbo-admin（管理控制台）

下载：
https://github.com/apache/dubbo-admin

解压后放到：D:\workspace\dubbo\dubbo-admin-develop

编译构建：mvn install

#### 编译问题1：

[ERROR] Failed to execute goal com.github.eirslett:frontend-maven-plugin:1.6:ins
tall-node-and-npm (install node and npm) on project dubbo-admin-ui: Could not do
wnload Node.js: Could not download https://nodejs.org/dist/v9.11.1/node-v9.11.1-
win-x64.zip: Connect to nodejs.org:443 [nodejs.org/104.20.22.46, nodejs.org/104.
20.23.46] failed: Connection timed out: connect -> [Help 1]

问题分析：

网络问题导致下载超时，到本地仓库查看对应文件为0字节：

解决办法：

https://nodejs.org/download/release/v9.11.1/中下载node-v9.11.1- win-x64.zip拷贝到本地仓库中。

这个地址也可以：https://nodejs.org/dist/v9.11.1/node-v9.11.1-win-x64.zip
不过很可能无法下载。

#### 编译问题2：

2021-01-01 17:12:26.990 ERROR 3724 --- [tor-Framework-0] org.apache.curator.Conn
ectionState       : Connection timed out for connection string (localhost:55947)
 and timeout (15000) / elapsed (16012)

解决办法：自动重试，不用干预


下一步，进入目录：D:\workspace\dubbo\dubbo-admin-develop\dubbo-admin-server\target

运行：java -jar dubbo-admin-server-0.2.0-SNAPSHOT.jar

#### 运行问题1：

2021-01-01 17:40:03.537 ERROR 12568 --- [           main] org.apache.curator.Con
nectionState       : Connection timed out for connection string (127.0.0.1:2183)
 and timeout (15000) / elapsed (49196)

解决办法：修改zookeeper的配置文件zoo.cfg:

把clientPort=2181改为clientPort=2183

测试：http://localhost:8080/

默认用户名：root

默认密码：root

#### （2）dubbo

下载：
https://github.com/apache/dubbo

解压后放到：D:\workspace\dubbo

编译构建：mvn install

然后在服务中POM.xml文件引用。

### 3、nacos

官网地址：https://nacos.io/zh-cn/index.html

#### （1）下载：

https://github.com/alibaba/nacos/releases/download/1.4.0/nacos-server-1.4.0.zip

也可以下载源代码自行编译。

编译错误：

Failed to execute goal org.apache.rat:apache-rat-plugin:0.12:check (default) on project nacos-core: Too many files with unapproved license: 1 See RAT report in: D:\MyWork\Nacos\core\target\rat.txt -> [Help 1]

解决办法：新建一个maven配置，在goal中输入install -Drat.skip=true，下图：



Gitee.com的镜像：https://gitee.com/mirrors/Nacos.git

#### （2）解压到：D:\nacos

#### （3）环境变量：

NACOS_HOME=D:\nacos
PATH增加%NACOS_HOME%\bin

#### （4）配置：
在mysql中创建数据库：create database nacos;
	切换到nacos数据库：use nacos;
	执行脚本：source D:\nacos\conf\nacos-mysql.sql
	修改D:\nacos\conf\application.properties:
```
		spring.datasource.platform=mysql
		db.num=1
		db.url.0=jdbc:mysql://127.0.0.1:3306/nacos?characterEncoding=utf8&connectTimeout=1000&socketTimeout=3000&autoReconnect=true&useUnicode=true&useSSL=false&serverTimezone=UTC
		db.user=root
		db.password=123456
```
#### (5)启动和测试

启动：startup.cmd

#### 启动错误：

Unable to start web server; nested exception is org.springframework.boot.web.server.WebServerException: Unable to start embedded Tomcat

。。。。。。

Caused by: org.springframework.beans.factory.BeanCreationException: Error creating bean with name 'distroFilterRegistration' defined in class path resource [com/alibaba/nacos/naming/web/NamingConfig.class]: Bean instantiation via factory method failed; nested exception is org.springframework.beans.BeanInstantiationException: 

解决办法：使用新命令来重新启动：startup -m standalone

因为使用startup实际上启动集群模式，需要把cluster.conf.example拷贝一份，命名为cluster.conf，在其中制定集群服务器的IP和端口。

验证：登陆http://metanet-nacos:8848/nacos，默认用户名和密码均为nacos	

### 4、seata

官方网站：https://seata.io/zh-cn/

#### （1）下载：

https://github.com/seata/seata/releases/download/v1.4.0/seata-server-1.4.0.zip

也可以下载源代码自行编译。Gitee.com上的镜像地址：https://gitee.com/mirrors/Seata.git

#### （2）解压到：

D:\seata

#### （3）环境变量：

SEATA_HOME=D:\nacos

PATH增加%SEATA_HOME%\bin

#### （4）配置：

修改D:\seata\conf\registry.conf：
```
registry {
  type = "nacos"
  nacos {
    application = "seata-server"
    serverAddr = "metanet-nacos:8848"
    group = "SEATA_GROUP"
    namespace = "public"
    cluster = "default"
    username = ""
    password = ""
  }
  ......


config {
  # file、nacos 、apollo、zk、consul、etcd3
  type = "nacos"

  nacos {
    serverAddr = "metanet-nacos:8848"
    namespace = "public"
    group = "SEATA_GROUP"
    username = ""
    password = ""
  }
  ......
```

修改D:\seata\conf\file.conf：
```
store {
  mode = "db"
  db {
    datasource = "druid"
    dbType = "mysql"
    driverClassName = "com.mysql.jdbc.Driver"
    url = "jdbc:mysql://127.0.0.1:3306/seata"
    user = "root"
    password = "radar"
	......
```

#### （5）创建数据库，执行脚本
```
create database seata;
use seata;

drop table if exists `global_table`;
create table `global_table` (
  `xid` varchar(128)  not null,
  `transaction_id` bigint,
  `status` tinyint not null,
  `application_id` varchar(32),
  `transaction_service_group` varchar(32),
  `transaction_name` varchar(128),
  `timeout` int,
  `begin_time` bigint,
  `application_data` varchar(2000),
  `gmt_create` datetime,
  `gmt_modified` datetime,
  primary key (`xid`),
  key `idx_gmt_modified_status` (`gmt_modified`, `status`),
  key `idx_transaction_id` (`transaction_id`)
);

-- the table to store BranchSession data
drop table if exists `branch_table`;
create table `branch_table` (
  `branch_id` bigint not null,
  `xid` varchar(128) not null,
  `transaction_id` bigint ,
  `resource_group_id` varchar(32),
  `resource_id` varchar(256) ,
  `lock_key` varchar(128) ,
  `branch_type` varchar(8) ,
  `status` tinyint,
  `client_id` varchar(64),
  `application_data` varchar(2000),
  `gmt_create` datetime,
  `gmt_modified` datetime,
  primary key (`branch_id`),
  key `idx_xid` (`xid`)
);

-- the table to store lock data
drop table if exists `lock_table`;
create table `lock_table` (
  `row_key` varchar(128) not null,
  `xid` varchar(96),
  `transaction_id` long ,
  `branch_id` long,
  `resource_id` varchar(256) ,
  `table_name` varchar(32) ,
  `pk` varchar(36) ,
  `gmt_create` datetime ,
  `gmt_modified` datetime,
  primary key(`row_key`)
);
```
#### （6）启动和测试

启动命令：seata-server.bat

在业务数据库中创建表：
```
drop table `undo_log`;
CREATE TABLE `undo_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `branch_id` bigint(20) NOT NULL,
  `xid` varchar(100) NOT NULL,
  `context` varchar(128) NOT NULL,
  `rollback_info` longblob NOT NULL,
  `log_status` int(11) NOT NULL,
  `log_created` datetime NOT NULL,
  `log_modified` datetime NOT NULL,
  `ext` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_undo_log` (`xid`,`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
```

然后开发业务端服务，进行测试

### 5、Gradle

#### (1)下载：

https://gradle.org/releases/

#### (2)解压到：

D:\gradle\gradle-6.7

#### (3)环境变量：

GRADLE_HOME=D:\gradle\gradle-6.7

GRADLE_USER_HOME=E:\maven-localRepository

PATH增加%GRADLE_HOME%\bin

#### (4)配置：

在D:\gradle\gradle-6.7\init.d目录下新建init.gradle，内容为：
```
allprojects {
    repositories {
        maven { url 'file:///e:/maven-localRepository'}
        mavenLocal()
        maven { name "Alibaba" ; url "https://maven.aliyun.com/repository/public" }
        maven { name "Bstek" ; url "http://nexus.bsdn.org/content/groups/public/" }
        mavenCentral()
    }

    buildscript { 
        repositories { 
            maven { name "Alibaba" ; url 'https://maven.aliyun.com/repository/public' }
            maven { name "Bstek" ; url 'http://nexus.bsdn.org/content/groups/public/' }
            maven { name "M2" ; url 'https://plugins.gradle.org/m2/' }
        }
    }
}
```
#### (5)使用

在eclipse、STS或者Android Studio中配置使用，略
