 sh nacos-config.sh -h 192.168.20.200 -p 8848 -g SEATA_GROUP -t METANET
