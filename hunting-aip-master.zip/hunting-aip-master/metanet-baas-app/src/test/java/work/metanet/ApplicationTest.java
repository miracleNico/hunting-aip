package work.metanet;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationTest {

	public static void main(String[] args) {
		
		//File file = FileUtil.file("F:/searchTopic/123456.txt");
		//FileUtil.appendLines(Arrays.asList(RandomUtil.randomString(10000)), file, Charset.forName("UTF-8"));
		
		
		//String base64Str = Base64.encode(FileUtil.file("F:/123.png"));
		//FileUtil.writeBytes(Base64.decode(base64Str), "F:/456.png");
		
		
		//FileUtil.writeBytes(Base64.decode(FileUtil.readString("F:/456.txt", "UTF-8")), "F:/456.png");
	}

}
